import requests
import pandas as pd


def getStockInfo(id):
    url = 'https://tw.screener.finance.yahoo.net/screener/ws?f=j&ShowID=' + str(id)
    res = requests.get(url)
    jd = res.json()['items']

    return jd

def updateStockCSV():
    df = pd.read_csv('Data/stock_id.csv', encoding="utf8")
    df_new = pd.DataFrame( columns=['代號', '公司', '產業', '上月收入', 'EPS累計','EPS上季', '本益比', '毛利率累計', '毛利率上季', '股價淨值比'])
    

    for i in range(len(df)):
        try:
            info = getStockInfo(df['id'][i])
            eps = info[0]['vFLD_EPS'].split('/', 1)
            profit = info[0]['vFLD_PROFIT'].split('/', 1)
            
            df_table = pd.read_html('https://www.cnyes.com/twstock/finratio.aspx?code=' + str(df['id'][i]), encoding='utf-8')
            df_table = df_table[0]

            for j in range(len(df_table)):
                if(df_table['名稱'][j] == '平均銷貨日數'):
                    days01 = df_table['2022年Q2'][j]
                    days02 = df_table['2022年Q1'][j]
                    days03 = df_table['2021年Q4'][j]
                elif(df_table['名稱'][j] == '純益率'):
                    value = df_table['2022年Q2'][j]
                elif(df_table['名稱'][j] == '負債占資產比率'):
                    own01 = df_table['2022年Q2'][j]
                    own02 = df_table['2022年Q1'][j]
                    own03 = df_table['2021年Q4'][j]

            try:
                days01 = float(days01)
            except:
                days01 = 0
            try:
                days02 = float(days02)
            except:
                days02 = 0
            try:
                days03 = float(days03)
            except:
                days03 = 0
            try:
                value = float(value)
            except:
                value = 0
            try:
                own01 = float(own01)
            except:
                own01 = 0
            try:
                own02 = float(own02)
            except:
                own02 = 0
            try:
                own03 = float(own03)
            except:
                own03 = 0
            temp = pd.DataFrame([[df['id'][i], df['name'][i], df['type'][i],info[0]['vGET_MONEY'], eps[0],eps[1],info[0]['vFLD_PER'], profit[0],profit[1], info[0]['vFLD_PBR'],days01,days02,days03,value,own01,own02,own03]], columns=['代號', '公司', '產業', '上月收入', 'EPS累計','EPS上季', '本益比', '毛利率累計', '毛利率上季', '股價淨值比','平均銷貨日數/2022Q2','平均銷貨日數/2022Q1','平均銷貨日數/2021Q4','純益率','負債比/2022Q2','負債比/2022Q1','負債比/2021Q4'])
            df_new = df_new.append(temp, ignore_index=True)
            
        except:
            continue
    
    df_new['本益比'] = df_new['本益比'].str.replace('倍', '')
    df_new['上月收入'] = df_new['上月收入'].str.replace('億元', '')

    for i in range(len(df_new)):
        try:
            df_new['EPS累計'][i] = float(df_new['EPS累計'][i])
        except:
            df_new['EPS累計'][i] = 0
        try:
            df_new['EPS上季'][i] = float(df_new['EPS上季'][i])
        except:
            df_new['EPS上季'][i] = 0
        try:
            df_new['本益比'][i] = float(df_new['本益比'][i])
        except:
            df_new['本益比'][i] = 0
        try:
            df_new['毛利率累計'][i] = float(df_new['毛利率累計'][i])
        except:
            df_new['毛利率累計'][i] = 0
        try:
            df_new['毛利率上季'][i] = float(df_new['毛利率上季'][i])
        except:
            df_new['毛利率上季'][i] = 0
        try:
            df_new['股價淨值比'][i] = float(df_new['股價淨值比'][i])
        except:
            df_new['股價淨值比'][i] = 0

    pd.DataFrame.to_csv(df_new, 'Data/stock_info.csv',encoding="utf_8_sig")


def getStockInfo(type):
    df_stock = pd.read_csv('Data/stock_info.csv', index_col=0)
    if(type == 0):
        return df_stock.to_html(classes=["table","table-bordered", "table-striped", "table-hover"]), df_stock.columns.values
    else:
        query = ''
        for i in range(len(type)):
            if type[i][0] == 'epsAll':
                query += 'EPS累計>=' + type[i][1] + '&'
            elif type[i][0] == 'epsLast':
                query += 'EPS上季>=' + type[i][1] + '&'
            elif type[i][0] == 'ratio':
                query += '本益比<=' + type[i][1] + '&'
            elif type[i][0] == 'profitAll':
                query += '毛利率累計>=' + type[i][1] + '&'
            elif type[i][0] == 'profitLast':
                query += '毛利率上季>=' + type[i][1] + '&'
            elif type[i][0] == 'pure':
                query += '純益率>=' + type[i][1] + '&'
            elif type[i][0] == 'value':
                query += '股價淨值比<=' + type[i][1] + '&'
        
        query = query[:-1]
        filtered_df=df_stock.query(query)
        
    return  filtered_df.to_html(classes=["table","table-bordered", "table-striped", "table-hover"]), filtered_df.columns.values