import stockResource
import pandas as pd
import requests
import re

from flask import Flask,render_template,jsonify, request, json
from flask_cors import CORS



app=Flask(__name__,static_url_path='', static_folder='static',template_folder='templates')
app.config['SCHEDULER_API_ENABLED'] = True
app.config['JSON_SORT_KEYS'] = False
CORS(app)



@app.route("/")
def hello_world():
    stock_info, title=stockResource.getStockInfo(0)
    return render_template('index.html',tables=stock_info)


@app.route("/query", methods=['POST'])
def query():

    query = []

    if request.form.get('chk_epsAll'):
        epsAll = request.form['txt_epsAll']
        query.append(['epsAll', epsAll])
    if request.form.get('chk_epsLast'):
        epsLast = request.form['txt_epsLast']
        query.append(['epsLast', epsLast])
    if request.form.get('chk_ratio'):
        ratio = request.form['txt_ratio']
        query.append(['ratio', ratio])
    if request.form.get('chk_profitAll'):
        profitAll = request.form['txt_profitAll']
        query.append(['profitAll', profitAll])
    if request.form.get('chk_profitLast'):
        profitLast = request.form['txt_profitLast']
        query.append(['profitLast', profitLast])
    if request.form.get('chk_pure'):
        pure = request.form['txt_pure']
        query.append(['pure', pure])
    if request.form.get('chk_value'):
        value = request.form['txt_value']
        query.append(['value', value])

    if len(query) == 0:
        stock_info, title=stockResource.getStockInfo(0)
        return render_template('index.html',tables=stock_info)
    
    else:
        stock_info, title=stockResource.getStockInfo(query)
        return render_template('index.html',tables=stock_info, lastquery=query)



if __name__ == '__main__':
    app.run(host = '0.0.0.0', port = 5000, debug = True)