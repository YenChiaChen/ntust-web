import mysql.connector
from mysql.connector import Error

HOST = '127.0.0.1'
DATABASE = 'stock'
USER = 'root'
PASSWORD = 'root'

def getSQLConnection():
    conn = mysql.connector.connect(
        host=HOST,          
        database=DATABASE, 
        user=USER,        
        password=PASSWORD) 
    return conn

def toJson(cursor):
    data = [dict((cursor.description[i][0], value) \
            for i, value in enumerate(row)) for row in cursor.fetchall()]
    return data